package com.example.todoapp;

import android.content.Context;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.security.Key;
import java.util.ArrayList;
import java.util.Dictionary;

public class MainActivity extends AppCompatActivity {


    static ArrayList<Task> tasks = new ArrayList<>();
    static ArrayAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button createTaskButton = findViewById(R.id.createTaskButton);
        ListView taskList = findViewById(R.id.taskList);



        createTaskButton.setOnClickListener(view -> {
            setContentView(R.layout.activity_crudview);
        });

        adapter=new ArrayAdapter<Task>(this,
                android.R.layout.simple_list_item_1,
                tasks);
        taskList.setAdapter(adapter);



    }
    public static void AddNewTask(String name, String date, String time){
        tasks.add(new Task(name, date, time));
        adapter.notifyDataSetChanged();

    }
}