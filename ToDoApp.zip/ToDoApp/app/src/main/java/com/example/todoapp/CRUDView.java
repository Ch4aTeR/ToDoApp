package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputEditText;

import java.time.LocalDateTime;
import java.util.Date;

public class CRUDView extends AppCompatActivity {

    static String name;
    static String date;
    static String time;
    TextInputEditText nameInput = findViewById(R.id.nameInput);
    EditText dateInput = findViewById(R.id.dateInput);
    EditText timeInput = findViewById(R.id.timeInput);

    Button save = findViewById(R.id.saveTask);
    Button delete = findViewById(R.id.deleteTask);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crudview);

        save.setOnClickListener(view -> {
            CreateNewTask();
        });

        delete.setOnClickListener(view -> {
            DeleteTask();
        });

    }

    public void CreateNewTask(){
        name = nameInput.getText().toString();
        date = dateInput.getText().toString();
        time = timeInput.getText().toString();

        MainActivity.AddNewTask(name, date, time);

        setContentView(R.layout.activity_main);
    }

    public void DeleteTask(){

        setContentView(R.layout.activity_main);
    }
    public void UpdateTask() {

        setContentView(R.layout.activity_main);
    }
}